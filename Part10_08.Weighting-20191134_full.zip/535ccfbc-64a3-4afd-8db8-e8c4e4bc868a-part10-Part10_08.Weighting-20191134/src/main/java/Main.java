

public class Main {

    public static void main(String[] args) {
        // Use this main program for testing your classes!
        Suitcase suitcase = new Suitcase(10);
        Item item = new Item ("apple", 5);
        
        suitcase.addItem(item);
        suitcase.printItems();
        
        
    }

}
