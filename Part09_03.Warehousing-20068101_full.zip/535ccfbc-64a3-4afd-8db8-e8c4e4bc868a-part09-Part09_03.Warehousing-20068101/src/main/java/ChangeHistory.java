
import java.util.ArrayList;

public class ChangeHistory {

    private ArrayList<Double> change;

    public ChangeHistory() {
        this.change = new ArrayList<>();

    }

    public void add(double status) {
        this.change.add(status);
    }

    public void clear() {
        this.change.clear();
    }

    public double maxValue() {
        if (this.change.isEmpty()) {
            return 0;
        }
        double helper = change.get(0);
        for (Double value : change) {
            if (helper < value) {
                helper = value;
            }

        }
        return helper;
    }

    public double minValue() {
        if (this.change.isEmpty()) {
            return 0;
        }
        double helper = change.get(0);
        for (Double value : change) {
            if (helper > value) {
                helper = value;
            }

        }
        return helper;
    }

    public double average() {
        int sum = 0;
        if (this.change.isEmpty()) {
            return sum;
        }    
        for (Double value : change) {
            sum += value;
        }
        return 1.0 * sum / this.change.size();
    }

    public String toString() {
        return this.change.toString();
    }
}
