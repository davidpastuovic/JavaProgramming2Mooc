
public class Book {

    private String name;
    private int recomAge;

    public Book(String name, int recomAge) {
        this.name = name;
        this.recomAge = recomAge;
    }

    public String getName() {
        return name;
    }

    public int getRecomAge() {
        return recomAge;
    }

    @Override
    public String toString() {
        return this.name + " (recommended for " + this.recomAge + " year-olds or older)";
    }

}
