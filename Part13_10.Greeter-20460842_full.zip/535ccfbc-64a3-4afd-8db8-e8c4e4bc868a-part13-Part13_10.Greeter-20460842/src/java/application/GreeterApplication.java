package application;

public class GreeterApplication {


    public static void main(String[] args) {
        System.out.println("Hellow world! :3");
    }
}
