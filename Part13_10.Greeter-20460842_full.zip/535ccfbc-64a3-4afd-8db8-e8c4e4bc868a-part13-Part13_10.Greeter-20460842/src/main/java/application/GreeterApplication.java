package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.control.TextField;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.layout.StackPane;

public class GreeterApplication extends Application {

    public void start(Stage window) throws Exception {

        //creating UI components
        Label label = new Label("Enter your name and start.");
        Button button = new Button("Start");
        TextField field = new TextField();

        //creating layout and adding components
        GridPane layout = new GridPane();
        layout.add(label, 0, 0);
        layout.add(field, 0, 1);
        layout.add(button, 0, 2);

        //styling the layout
        layout.setPrefSize(300, 180);
        layout.setAlignment(Pos.CENTER);
        layout.setVgap(10);
        layout.setHgap(10);
        layout.setPadding(new Insets(20, 20, 20, 20));

        //creating first view
        Scene first = new Scene(layout);

        //creating welcoming view
        Label welcomeText = new Label();
        StackPane welcomeLayout = new StackPane();
        welcomeLayout.setPrefSize(300, 180);
        welcomeLayout.getChildren().add(welcomeText);
        welcomeLayout.setAlignment(Pos.CENTER);
        Scene second = new Scene(welcomeLayout);

        //adding an event handler
        button.setOnAction((event) -> {
            window.setScene(second);
            welcomeText.setText("Welcome " + field.getText() + "!");
        });

        window.setScene(first);
        window.show();

    }

    public static void main(String[] args) {
        launch(GreeterApplication.class);
        System.out.println("Hellow world! :3");
    }
}
