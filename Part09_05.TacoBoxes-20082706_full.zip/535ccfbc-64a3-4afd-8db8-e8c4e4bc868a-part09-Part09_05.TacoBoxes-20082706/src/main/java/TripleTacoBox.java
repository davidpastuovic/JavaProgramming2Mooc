
public class TripleTacoBox implements TacoBox {
    
    private int tacos;
    
    public TripleTacoBox() {
    this.tacos = 3; 
    }

    @Override
    public int tacosRemaining() {
        return this.tacos;
    }

    @Override
    public void eat() {
        this.tacos--;
       if (tacosRemaining() < 1) {
           this.tacos = 0;
       } 
    }
    
}
