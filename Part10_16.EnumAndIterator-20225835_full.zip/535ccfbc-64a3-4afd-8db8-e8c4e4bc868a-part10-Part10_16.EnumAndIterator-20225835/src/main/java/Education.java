
public enum Education {
    PHD, 
    MA, 
    BA, 
    HS;
}
