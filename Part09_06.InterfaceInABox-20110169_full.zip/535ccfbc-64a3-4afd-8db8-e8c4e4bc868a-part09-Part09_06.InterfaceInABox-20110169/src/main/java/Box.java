
import java.util.ArrayList;

public class Box implements Packable {

    private ArrayList<Packable> items;
    private double maxCapacity;

    public Box(double maximumCapacity) {
        this.items = new ArrayList<>();
        this.maxCapacity = maximumCapacity;
    }

    public void add(Packable item) {
        if (this.weight() + item.weight() <= maxCapacity) {
            this.items.add(item);
            
        }
    }

    @Override
    public String toString() {
        return "Box: " + this.items.size() + " items, total weight " + this.weight() + " kg";
    }

    @Override
    public double weight() {
      double weightSum = 0.0;
      for (Packable item : items) {
          weightSum += item.weight();
      }
      return weightSum;
      
    }

}
