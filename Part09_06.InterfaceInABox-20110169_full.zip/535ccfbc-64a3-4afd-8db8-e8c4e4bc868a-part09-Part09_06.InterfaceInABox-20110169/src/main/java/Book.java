
public class Book implements Packable {
    private String AuthorName;
    private String BookName;
    private double weight;
    
    public Book (String autor, String book, double initWeight) {
        this.AuthorName = autor;
        this.BookName = book;
        this.weight = initWeight;
    }

    @Override
    public double weight() {
        return this.weight;
    }
    @Override
    public String toString() {
        return this.AuthorName + ": " + this.BookName;
    }
    
    
}
