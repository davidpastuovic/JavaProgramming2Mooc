package buttonandlabel;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ButtonAndLabelApplication extends Application {

    @Override
    public void start(Stage window) {

        Button button = new Button("This is button");
        Label label = new Label("This is label");

        FlowPane components = new FlowPane();
        components.getChildren().add(label);
        components.getChildren().add(button);
        

        Scene scene = new Scene(components);
        window.setScene(scene);
        window.show();
    }

    public static void main(String[] args) {
        launch(ButtonAndLabelApplication.class);
        System.out.println("Hello world!");
    }
}
