package buttonandlabel;


public class ButtonAndLabelApplication {


    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
