
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("12-04.1 12-04.2")
public class ListTest {

    @Test
    public void noTests() {

    }

}
