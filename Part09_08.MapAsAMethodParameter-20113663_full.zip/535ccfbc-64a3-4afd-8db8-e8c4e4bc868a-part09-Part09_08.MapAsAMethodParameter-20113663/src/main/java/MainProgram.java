import java.util.Map;

public class MainProgram {

    public static void main(String[] args) {
        // test your method here

    }

   public static int returnSize(Map map) {
       return map.size();
   }
}
