
import java.util.Random;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random ran = new Random();
        System.out.println("How many numbers?");
        int numOfNums = Integer.valueOf(scanner.nextLine());

        for (int i = 0; i < numOfNums; i++) {
            int nums = ran.nextInt(11);
            System.out.println(nums);
        }
    }

}
