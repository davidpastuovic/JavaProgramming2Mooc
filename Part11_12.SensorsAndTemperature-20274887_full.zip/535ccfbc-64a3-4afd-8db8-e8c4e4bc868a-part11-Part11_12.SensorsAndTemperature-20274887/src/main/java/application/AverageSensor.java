package application;

import java.util.List;
import java.util.ArrayList;

public class AverageSensor implements Sensor {

    private List<Sensor> sensors;
    private List<Integer> averageReadings;

    public AverageSensor() {
        this.sensors = new ArrayList<>();
        this.averageReadings = new ArrayList<>();
    }

    @Override
    public boolean isOn() {
        boolean isOn = false;
        for (Sensor sen : sensors) {
            if (sen.isOn() == true) {
                isOn = true;
            } else {
                isOn = false;
            }

        }
        return isOn;
    }

    @Override
    public void setOn() {
        for (Sensor sen : sensors) {
            if (sen.isOn() == false) {
                sen.setOn();
            }
        }

    }

    @Override
    public void setOff() {
        for (Sensor sen : sensors) {
            if (sen.isOn() == true) {
                sen.setOff();
            }
        }

    }

    @Override
    public int read() {

        int sum = 0;
        if (isOn() && !sensors.isEmpty()) {

            for (Sensor sen : sensors) {

                sum += sen.read();
            }

            int average = sum / sensors.size();

            averageReadings.add(average);

            return average;

        } else {
            throw new IllegalArgumentException("error getting average of sensors");
        }

    }

    public void addSensor(Sensor toAdd) {
        this.sensors.add(toAdd);

    }

    public List<Integer> readings() {
        return averageReadings;
    }

}
