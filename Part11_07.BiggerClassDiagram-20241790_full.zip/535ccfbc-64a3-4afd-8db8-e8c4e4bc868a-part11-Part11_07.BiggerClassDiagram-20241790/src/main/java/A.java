
public class A implements IA{
    
}
