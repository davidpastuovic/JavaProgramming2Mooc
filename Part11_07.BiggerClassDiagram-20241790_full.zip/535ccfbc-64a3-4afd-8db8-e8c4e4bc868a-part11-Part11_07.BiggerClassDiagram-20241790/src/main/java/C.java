import java.util.ArrayList;

public class C extends B implements IC{
     
    private ArrayList<E> e;
}
