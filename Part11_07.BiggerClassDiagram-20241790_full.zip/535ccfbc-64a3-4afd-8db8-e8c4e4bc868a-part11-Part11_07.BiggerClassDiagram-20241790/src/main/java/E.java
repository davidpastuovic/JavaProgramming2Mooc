import java.util.ArrayList;

public class E {
    
    private ArrayList<C> c;
}
