
public class D {
    
    private IA ia;
    
}
