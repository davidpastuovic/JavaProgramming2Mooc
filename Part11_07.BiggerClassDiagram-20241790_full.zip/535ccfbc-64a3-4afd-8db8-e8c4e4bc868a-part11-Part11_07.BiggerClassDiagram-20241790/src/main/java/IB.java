
public interface IB {
    
}
