
public interface IA {
    
}
