package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

public class MultipleViews extends Application {

    public void start(Stage window) {

        BorderPane layout = new BorderPane();
        VBox layoutSecond = new VBox();
        GridPane layoutThird = new GridPane();

        Scene first = new Scene(layout);
        Scene second = new Scene(layoutSecond);
        Scene third = new Scene(layoutThird);

        layout.setTop(new Label("First view!"));
        Button toSecond = new Button("To the second view!");
        Button toThird = new Button("To the third view!");
        Button toFirst = new Button("To the first view!");
        layout.setCenter(toSecond);
        Label secondLabel = new Label("Second view!");
        Label thirdLabel = new Label("Third view!");

        layoutSecond.getChildren().addAll(toThird, secondLabel);
        
        layoutThird.add(thirdLabel, 0, 0);
        layoutThird.add(toFirst, 1, 1);

        toSecond.setOnAction((event) -> {
            window.setScene(second);
        });

        toThird.setOnAction((event) -> {
            window.setScene(third);
        });

        toFirst.setOnAction((event) -> {
            window.setScene(first);
        });

        window.setScene(first);
        window.show();

    }

    public static void main(String[] args) {
        launch(MultipleViews.class);
        System.out.println("Hello world!");
    }

}
