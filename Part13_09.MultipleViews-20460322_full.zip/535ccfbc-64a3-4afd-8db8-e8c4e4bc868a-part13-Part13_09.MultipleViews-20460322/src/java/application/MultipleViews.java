package application;

public class MultipleViews {

    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
