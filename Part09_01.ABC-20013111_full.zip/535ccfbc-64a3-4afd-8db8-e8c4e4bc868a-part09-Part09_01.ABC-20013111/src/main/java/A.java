
public class A {
    
    
    public void a() {
        System.out.println("A");
    }
}
