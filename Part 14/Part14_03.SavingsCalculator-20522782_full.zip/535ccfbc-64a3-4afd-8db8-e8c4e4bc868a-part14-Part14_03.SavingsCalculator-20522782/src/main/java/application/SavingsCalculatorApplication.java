package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Slider;
import javafx.scene.control.Label;
import javafx.geometry.Insets;

public class SavingsCalculatorApplication extends Application {

    @Override
    public void start(Stage window) throws Exception {

        BorderPane layout = new BorderPane();

        NumberAxis xAxis = new NumberAxis(0, 30, 1);
        NumberAxis yAxis = new NumberAxis();

        VBox box = new VBox();
        box.setSpacing(10);
        BorderPane boxPane1 = new BorderPane();
        BorderPane boxPane2 = new BorderPane();
        box.getChildren().addAll(boxPane1, boxPane2);

        Slider savingsSlider = new Slider(25, 250, 25);
        savingsSlider.setBlockIncrement(1);
        savingsSlider.setShowTickMarks(true);
        savingsSlider.setShowTickLabels(true);

        Slider interestRateSlider = new Slider(0, 10, 0);
        interestRateSlider.setBlockIncrement(0.1);
        interestRateSlider.setMinorTickCount(10);
        interestRateSlider.setShowTickMarks(true);
        interestRateSlider.setShowTickLabels(true);

        Label savingsLabel = new Label("25");
        Label interestRateLabel = new Label("0");

        boxPane1.setLeft(new Label("Monthly savings"));
        boxPane1.setCenter(savingsSlider);
        boxPane1.setRight(savingsLabel);
        boxPane1.setPadding(new Insets(10));

        boxPane2.setLeft(new Label("Yearly interest rate"));
        boxPane2.setCenter(interestRateSlider);
        boxPane2.setRight(interestRateLabel);
        boxPane2.setPadding(new Insets(10));

        LineChart<Number, Number> lineChart = new LineChart(xAxis, yAxis);
        lineChart.setTitle("Savings over time");
        lineChart.setAnimated(false);
        lineChart.setLegendVisible(false);

        XYChart.Series monthlySavingsSeries = new XYChart.Series();
        monthlySavingsSeries.setName("Monthly Savings");

        XYChart.Series savingsWithInterestSeries = new XYChart.Series();
        savingsWithInterestSeries.setName("Savings with Interest");

        lineChart.getData().addAll(monthlySavingsSeries, savingsWithInterestSeries);

        // Update chart data when sliders change
        savingsSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateChart(monthlySavingsSeries, savingsWithInterestSeries, savingsSlider.getValue(), interestRateSlider.getValue());
            savingsLabel.setText(String.format("%.2f", newValue));
        });

        interestRateSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            updateChart(monthlySavingsSeries, savingsWithInterestSeries, savingsSlider.getValue(), interestRateSlider.getValue());
            interestRateLabel.setText(String.format("%.2f", newValue));
        });

        layout.setTop(box);
        layout.setCenter(lineChart);

        Scene view = new Scene(layout, 800, 600);
        window.setScene(view);
        window.show();
        updateChart(monthlySavingsSeries, savingsWithInterestSeries, savingsSlider.getValue(), interestRateSlider.getValue());

    }

    public static void main(String[] args) {
        launch(SavingsCalculatorApplication.class);
        System.out.println("Hello world!");
    }

    private void updateChart(XYChart.Series monthlySavingsSeries, XYChart.Series savingsWithInterestSeries, double monthlySavings, double yearlyInterestRate) {
        monthlySavingsSeries.getData().clear();
        savingsWithInterestSeries.getData().clear();

        double totalWithoutInterest = 0.0;
        double totalWithInterest = 0.0;

        for (int year = 0; year <= 30; year++) {
            monthlySavingsSeries.getData().add(new XYChart.Data<>(year, totalWithoutInterest));
            savingsWithInterestSeries.getData().add(new XYChart.Data<>(year, totalWithInterest));
            totalWithoutInterest += monthlySavings * 12;
            totalWithInterest += monthlySavings * 12;
            totalWithInterest *= (1 + yearlyInterestRate / 100);

        }
    }

}
