package application;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("14-04")
public class UnfairAdvertisementApplicationTest {

    @Test
    public void noTests() {

    }
}
