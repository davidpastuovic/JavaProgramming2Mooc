package asteroids;

import javafx.scene.shape.Polygon;

public class Ship extends Character {

    public Ship(int x, int y) {
        super(new Polygon(-9, -9, 10, 0, -9, 9), x, y);
    }
}
