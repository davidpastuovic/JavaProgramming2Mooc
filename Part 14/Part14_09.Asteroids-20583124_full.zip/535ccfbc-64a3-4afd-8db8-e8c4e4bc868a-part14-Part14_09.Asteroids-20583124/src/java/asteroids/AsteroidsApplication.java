package asteroids;

public class AsteroidsApplication {

    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }

    public static int partsCompleted() {
        // State how many parts you have completed using the return value of this method
        return 0;
    }

}
