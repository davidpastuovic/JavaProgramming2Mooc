
import java.util.List;
import java.util.ArrayList;

public class Herd implements Movable {

    private List<Movable> organisms;

    public Herd() {
        this.organisms = new ArrayList<>();

    }

    public void addToHerd(Movable movable) {
        organisms.add(movable);
    }

    @Override
    public void move(int dx, int dy) {
        for (Movable m : organisms) {
            m.move(dx, dy);
        }

    }

    @Override
    public String toString() {
        String helper = "";
        for (Movable m : organisms) {
            helper += m.toString() + " " + "\n";
        }
        return helper;
    }

}
