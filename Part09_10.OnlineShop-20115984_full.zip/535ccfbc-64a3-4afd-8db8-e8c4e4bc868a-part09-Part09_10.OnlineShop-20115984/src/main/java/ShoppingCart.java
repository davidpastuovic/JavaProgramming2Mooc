
import java.util.Map;
import java.util.HashMap;

public class ShoppingCart {

    private Map<String, Item> cart;

    public ShoppingCart() {
        this.cart = new HashMap<>();
    }

    public void add(String product, int price) {
        if (cart.keySet().contains(product)) {
            increaseQuantity(product);
        } else {
            cart.put(product, new Item(product, 1, price));
        }
    }

    public void increaseQuantity(String product) {
        this.cart.get(product).increaseQuantity();
    }
    public int price() {
        int totalPrice = 0;
        for (Item i : this.cart.values()) {
            totalPrice += i.price();
        }
        return totalPrice;
    }
    public void print() {
        for (Item i : this.cart.values()) {
            System.out.println(i);
        }
    }
}
