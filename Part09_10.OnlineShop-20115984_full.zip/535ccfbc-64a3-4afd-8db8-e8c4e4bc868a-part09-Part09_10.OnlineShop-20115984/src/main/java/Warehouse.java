
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;

public class Warehouse {

    private Map<String, Integer> productPriceMap;
    private Map<String, Integer> productStockMap;

    public Warehouse() {
        this.productPriceMap = new HashMap<>();
        this.productStockMap = new HashMap<>();
    }

    public void addProduct(String product, int price, int stock) {
        productPriceMap.put(product, price);
        productStockMap.put(product, stock);

    }

    public int price(String product) {

        for (String products : productPriceMap.keySet()) {
            if (!productPriceMap.containsKey(product)) {
                return -99;
            }
        }
        return productPriceMap.get(product);

    }

    public int stock(String product) {
        return this.productStockMap.getOrDefault(product, 0);
    }

    public boolean take(String product) {
        if (this.stock(product) > 0) {

            productStockMap.put(product, productStockMap.get(product) - 1);

            return true;
        }

        return false;

    }
    public Set<String> products() {
        Set<String> setOfProducts = new HashSet<>();
        for (String products : this.productPriceMap.keySet()) {
            setOfProducts.add(products);
        }
        return setOfProducts;
    }
}
