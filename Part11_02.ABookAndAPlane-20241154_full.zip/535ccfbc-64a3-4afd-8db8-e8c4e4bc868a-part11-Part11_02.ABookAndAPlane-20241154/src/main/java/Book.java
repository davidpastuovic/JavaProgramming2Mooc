
public class Book {
    private String name;
    private String author;
    private int pageCount;
    
}
