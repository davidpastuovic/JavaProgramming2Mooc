
import java.util.ArrayList;

public class OneItemBox extends Box {

    private int capacity;
    private ArrayList<Item> oneItem;

    public OneItemBox() {
        this.capacity = 1;
        this.oneItem = new ArrayList<>();
    }

    @Override
    public void add(Item item) {
        if (oneItem.size() < this.capacity) {
            oneItem.add(item);
        }
    }

    @Override
    public boolean isInBox(Item item) {
        if (!this.oneItem.contains(item)) {
            return false;
        }
        return true;
    }

}
