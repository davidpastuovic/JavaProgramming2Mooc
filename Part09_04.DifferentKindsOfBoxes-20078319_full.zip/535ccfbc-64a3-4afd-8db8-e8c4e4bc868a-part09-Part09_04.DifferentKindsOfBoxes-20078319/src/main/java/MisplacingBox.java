
import java.util.ArrayList;

public class MisplacingBox extends Box {

    private ArrayList<Item> empty;

    public MisplacingBox() {
        this.empty = new ArrayList<>();
    }

    @Override
    public void add(Item item) {
        this.empty.add(item);
    }

    @Override
    public boolean isInBox(Item item) {
        return false;
    }
}
