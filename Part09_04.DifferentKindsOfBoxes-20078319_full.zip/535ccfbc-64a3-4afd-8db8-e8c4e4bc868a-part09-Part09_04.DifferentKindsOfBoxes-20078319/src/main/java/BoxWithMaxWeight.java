
import java.util.ArrayList;

public class BoxWithMaxWeight extends Box {

    private int maxWeight;
    private ArrayList<Item> box;

    public BoxWithMaxWeight(int capacity) {

        this.maxWeight = capacity;
        this.box = new ArrayList<>();
    }

    public int currentAmount() {
        int sum = 0;

        for (Item items : box) {

            sum += items.getWeight();
        }
        return sum;

    }

    @Override
    public void add(Item item) {
        if (currentAmount() + item.getWeight() <= this.maxWeight) {
            this.box.add(item);
        }

    }

    @Override
    public boolean isInBox(Item item) {
        if (!this.box.contains(item)) {
            return false;
        }
        return true;
    }

}
