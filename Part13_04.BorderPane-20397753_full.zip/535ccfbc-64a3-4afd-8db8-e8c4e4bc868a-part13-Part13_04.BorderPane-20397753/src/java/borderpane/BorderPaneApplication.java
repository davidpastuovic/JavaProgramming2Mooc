package borderpane;


public class BorderPaneApplication {


    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
