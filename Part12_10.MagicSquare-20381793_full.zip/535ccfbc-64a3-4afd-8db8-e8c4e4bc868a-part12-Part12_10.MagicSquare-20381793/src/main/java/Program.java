
public class Program {

    public static void main(String[] args) {
        // Test the MagicSquare class here

        /*MagicSquareFactory msFactory = new MagicSquareFactory();
        System.out.println(msFactory.createMagicSquare(5));*/
        MagicSquare sq = new MagicSquare(3);
        sq.placeValue(0, 0, 8);
        sq.placeValue(1, 0, 1);
        sq.placeValue(2, 0, 6);
        sq.placeValue(0, 1, 3);
        sq.placeValue(1, 1, 5);
        sq.placeValue(2, 1, 7);
        sq.placeValue(0, 2, 4);
        sq.placeValue(1, 2, 9);
        sq.placeValue(2, 2, 2);

        System.out.println(sq.sumsOfDiagonals());

    }
}
