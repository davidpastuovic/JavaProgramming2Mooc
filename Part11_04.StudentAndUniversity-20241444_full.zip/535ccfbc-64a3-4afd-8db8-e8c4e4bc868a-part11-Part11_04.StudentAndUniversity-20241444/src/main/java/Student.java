
public class Student {

    private int studentID;
    private String name;
    private University university;
}
