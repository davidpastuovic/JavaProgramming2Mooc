
import java.util.ArrayList;

public class University {

    private String name;
    private ArrayList<Student> students;

}
