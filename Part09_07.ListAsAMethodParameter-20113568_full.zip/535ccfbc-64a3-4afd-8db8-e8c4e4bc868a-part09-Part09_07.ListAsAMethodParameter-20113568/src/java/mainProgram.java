

public class mainProgram {

    public static void main(String[] args) {
        // test your method here

    }

    // Implement here a method returnSize
    // which returns the size of the list given to it
    //as a parameter
}
