
import java.util.ArrayList;
import java.util.HashMap;

public class VehicleRegistry {

    private HashMap<LicensePlate, String> liPlateHashMap;

    public VehicleRegistry() {
        this.liPlateHashMap = new HashMap<>();
    }

    public boolean add(LicensePlate licensePlate, String owner) {
        for (LicensePlate plate : this.liPlateHashMap.keySet()) {
            if (plate.equals(licensePlate)) {
                return false;
            }
        }

        this.liPlateHashMap.put(licensePlate, owner);
        return true;

    }

    public String get(LicensePlate licensePlate) {

        return this.liPlateHashMap.getOrDefault(licensePlate, null);
    }

    public boolean remove(LicensePlate licensePlate) {
        if (!this.liPlateHashMap.containsKey(licensePlate)) {
            return false;

        }
        this.liPlateHashMap.remove(licensePlate);

        return true;
    }

    public void printLicensePlates() {
        for (LicensePlate plate : this.liPlateHashMap.keySet()) {
            System.out.println(plate);
        }
    }

    public void printOwners() {
        ArrayList<String> owners = new ArrayList<>();
        for (String owner : this.liPlateHashMap.values()) {
            if (!owners.contains(owner)) {
                owners.add(owner);
            }
        }
        for (String owner : owners) {
            System.out.println(owner); 
        }
    }

}
