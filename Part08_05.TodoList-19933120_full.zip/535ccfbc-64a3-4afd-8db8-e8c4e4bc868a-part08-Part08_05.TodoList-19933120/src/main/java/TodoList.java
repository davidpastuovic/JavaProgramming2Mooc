import java.util.ArrayList;

public class TodoList {
    private ArrayList<String> chores;
    
    
    public TodoList () {
        this.chores = new ArrayList<>();
    }
    
    public void add(String task) {
        this.chores.add(task);
    }
    public void print() {
        for (int i = 0; i < this.chores.size(); i++) {
            System.out.println((i + 1) + ": " + this.chores.get(i));
        }
    }
    public void remove(int number) {
        this.chores.remove(number - 1);
    }
}
