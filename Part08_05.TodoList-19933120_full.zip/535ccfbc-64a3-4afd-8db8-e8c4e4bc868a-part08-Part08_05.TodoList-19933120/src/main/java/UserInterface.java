
import java.util.Scanner;

public class UserInterface {

    private TodoList todoList;
    private Scanner scanner;
    
    public UserInterface(TodoList todoList, Scanner scanner) {
        this.todoList = todoList;
        this.scanner = scanner;
    }

    public void start() {
        
        while (true) {
            System.out.print("Command:");
            String input = scanner.nextLine();
            if (input.equals("stop")) {
                break;
            }
            if (input.equals("add")) {
                System.out.print("To add:");
                String task = scanner.nextLine();
                this.todoList.add(task);
                
            }
            if (input.equals("list")) {
                this.todoList.print();
            }
            if (input.equals("remove")) {
                System.out.print("Which one is removed?");
                int removed = Integer.valueOf(scanner.nextLine());
                this.todoList.remove(removed);
            }
            
        }
    }
}
