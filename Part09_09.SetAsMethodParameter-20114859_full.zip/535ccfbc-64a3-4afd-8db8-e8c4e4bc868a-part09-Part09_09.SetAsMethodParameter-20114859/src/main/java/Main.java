import java.util.Set;

public class Main {

    public static void main(String[] args) {
        // You can test your method here

    }

  public static int returnSize (Set set) {
      return set.size();
  }

}
