

public class Main {

    public static void main(String[] args) {
        // You can test your method here

    }

    // implement the method returnSize here, which returns
    // the number of elements in the set that it receives as a parameter.

}
