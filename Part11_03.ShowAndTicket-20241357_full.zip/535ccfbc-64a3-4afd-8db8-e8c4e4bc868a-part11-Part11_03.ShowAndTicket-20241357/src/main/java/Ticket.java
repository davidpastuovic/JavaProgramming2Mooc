

public class Ticket {

    private int seat;
    private int code;
    private Show shows;

}
