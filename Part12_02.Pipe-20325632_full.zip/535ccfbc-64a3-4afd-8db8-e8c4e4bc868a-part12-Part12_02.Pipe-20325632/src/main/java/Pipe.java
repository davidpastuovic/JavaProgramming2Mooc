
import java.util.List;
import java.util.ArrayList;

public class Pipe<T> {

    ArrayList<T> pipeList;

    public Pipe() {
        this.pipeList = new ArrayList<>();
    }

    public void putIntoPipe(T value) {
        this.pipeList.add(value);
    }

    public T takeFromPipe() {
        if(this.pipeList.isEmpty()) {
            return null;
        }
        T pipeValue = this.pipeList.get(0);
        this.pipeList.remove(0);
        return pipeValue;

    }

    public boolean isInPipe() {
        return !this.pipeList.isEmpty();
    }
}
