
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("12-02")
public class PipeTest {

    @Test
    public void noTests() {

    }
}
