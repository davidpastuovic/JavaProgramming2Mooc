package dictionary;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

public class SaveableDictionary {

    private Map<String, String> dictionary;
    private String file;

    public SaveableDictionary() {
        this.dictionary = new HashMap<>();
    }

    public SaveableDictionary(String file) {
        this();
        this.file = file;
    }

    public void add(String words, String translation) {
        if (dictionary.containsKey(words)) {
            return;
        }
        dictionary.put(words, translation);
        dictionary.put(translation, words);
    }

    public String translate(String word) {
        return this.dictionary.get(word);

    }

    public void delete(String word) {
        String translation = translate(word);
        this.dictionary.remove(word);
        this.dictionary.remove(translation);
    }

    public boolean load() {
        try {
            Files.lines(Paths.get(this.file))
                    .map(m -> m.split(":"))
                    .forEach(part -> {
                        this.dictionary.put(part[0], part[1]);
                        this.dictionary.put(part[1], part[0]);

                    });

            return true;
        } catch (IOException e) {

            return false;
        }
    }

    public boolean save() {
        try {
            PrintWriter writer = new PrintWriter(new File(this.file));
            saveWords(writer);

            writer.close();

        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public void saveWords(PrintWriter writer) throws IOException {

        List<String> alreadySaved = new ArrayList<>();

        dictionary.keySet().stream().forEach(word -> {

            if (alreadySaved.contains(word)) {

                return;

            }

            String translate = word + ":" + dictionary.get(word);

            writer.println(translate);

            alreadySaved.add(word);

            alreadySaved.add(dictionary.get(word));

        });
    }
}
