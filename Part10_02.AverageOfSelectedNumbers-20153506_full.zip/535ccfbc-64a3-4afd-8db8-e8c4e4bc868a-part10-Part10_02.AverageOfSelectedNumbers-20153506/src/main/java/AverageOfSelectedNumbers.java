
import java.util.ArrayList;
import java.util.Scanner;

public class AverageOfSelectedNumbers {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Input numbers, type \"end\" to stop.");

        ArrayList<Integer> positive = new ArrayList<>();
        ArrayList<Integer> negative = new ArrayList<>();

        while (true) {
            String number = scanner.nextLine();
            if (number.equals("end")) {
                break;
            } else if (Integer.valueOf(number) >= 0) {
                positive.add(Integer.valueOf(number));
            } else {
                negative.add(Integer.valueOf(number));
            }
        }

        double averageOfPositive = positive.stream()
                .mapToInt(s -> Integer.valueOf(s))
                .filter(number -> number >= 0)
                .average()
                .getAsDouble();
        double averageOfNegative = negative.stream()
                .mapToInt(s -> Integer.valueOf(s))
                .filter(number -> number < 0)
                .average()
                .getAsDouble();

        System.out.println("Print the average of the negative numbers or the positive numbers? (n/p)");

        String decision = scanner.nextLine();

        if (decision.equals("p")) {
            System.out.println("Average of positive numbers: " + averageOfPositive);
        } else if (decision.equals("n")) {
            System.out.println("Average of negative numbers: " + averageOfNegative);
        } else {
            System.out.println("Wrong input.");
        }

    }
}
