package application;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("13-12")
public class VocabularyPracticeTest {

    @Test
    public void noTests() {

    }
}
