package application;


// END SOLUTION
public class VocabularyPracticeApplication {


    public static void main(String[] args) {
    }
}
