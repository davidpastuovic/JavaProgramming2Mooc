
public class Player {
    private String name;
    
    
    public void play() {
        
    }
    
    public void printName() {
        
    }
    
}
